import './App.css';

import CountryCapitalGame from './components/CountryCapitalGame'

function App() {
  return (
    <div className="App">
      <CountryCapitalGame />
    </div>
  );
}

export default App;
